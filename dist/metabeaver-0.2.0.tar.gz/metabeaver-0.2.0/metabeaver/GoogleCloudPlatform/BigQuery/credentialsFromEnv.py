# Create a credentials object from the environment variables.
# Env Vars should be available on a windows system if the GCP SDK is installed.